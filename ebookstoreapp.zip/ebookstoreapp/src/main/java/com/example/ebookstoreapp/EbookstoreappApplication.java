package com.example.ebookstoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class EbookstoreappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
		System.out.println("\n\n\n e book store is working \n\n\n");
	}

}
